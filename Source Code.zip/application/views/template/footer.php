<!-- concludes the body -->
</body>

<!-- concludes the html -->
</html>