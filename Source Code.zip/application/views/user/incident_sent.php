<h1>Your incident Report has been submitted.</h1>
<br>
<button onclick="location.href='<?php echo base_url('user');?>'" class="btn btn-primary">Okay</button>